"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.makeScanInput = exports.notEmptyObject = exports.primitivesToString = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const debug_1 = __importDefault(require("debug"));
const debug = (0, debug_1.default)("handler");
/**
 * Recursively converts objects to strings. If the input is a primitive, it calls String on it, otherwise
 * it recurses over the object or array items
 */
function primitivesToString(input) {
    if (typeof input === "object") {
        if (Array.isArray(input)) {
            return input.map(primitivesToString);
        }
        else {
            return Object.fromEntries(Object.entries(input).map(([key, value]) => [
                key,
                primitivesToString(value),
            ]));
        }
    }
    return String(input);
}
exports.primitivesToString = primitivesToString;
/**
 * Returns true if the argument is an object that has at least 1 key
 */
function notEmptyObject(obj) {
    if (typeof obj === "object" && obj !== null) {
        return Object.keys(obj).length > 0;
    }
    return false;
}
exports.notEmptyObject = notEmptyObject;
function makeScanInput(event, startKey) {
    var _a, _b, _c, _d, _e;
    return {
        Select: "COUNT",
        TableName: event.tableName,
        ExclusiveStartKey: startKey,
        FilterExpression: event.dynamo && event.dynamo.expression.length > 0
            ? (_a = event.dynamo) === null || _a === void 0 ? void 0 : _a.expression
            : undefined,
        ExpressionAttributeNames: notEmptyObject((_b = event.dynamo) === null || _b === void 0 ? void 0 : _b.expressionNames)
            ? (_c = event.dynamo) === null || _c === void 0 ? void 0 : _c.expressionNames
            : undefined,
        ExpressionAttributeValues: notEmptyObject((_d = event.dynamo) === null || _d === void 0 ? void 0 : _d.expressionValues)
            ? primitivesToString((_e = event.dynamo) === null || _e === void 0 ? void 0 : _e.expressionValues)
            : undefined,
    };
}
exports.makeScanInput = makeScanInput;
const handler = async (event) => {
    debug("Incoming event data from AppSync: %o", event);
    const dbClient = new client_dynamodb_1.DynamoDB({});
    let count = 0;
    let startKey = undefined;
    while (true) {
        const scanArgs = makeScanInput(event, startKey);
        debug("Executing the following Dynamo scan: %o", scanArgs);
        const res = await dbClient.scan(scanArgs);
        count += res.Count || 0;
        // Keep looping if there is more data
        if (res.LastEvaluatedKey) {
            startKey = res.LastEvaluatedKey;
        }
        else {
            break;
        }
    }
    return count;
};
exports.handler = handler;
