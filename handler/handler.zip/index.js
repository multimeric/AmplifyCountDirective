"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
function primitivesToString(input) {
    if (typeof input === "object") {
        if (Array.isArray(input)) {
            return input.map(primitivesToString);
        }
        else {
            return Object.fromEntries(Object.entries(input).map(([key, value]) => [key, primitivesToString(value)]));
        }
    }
    return input.toString();
}
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    const dbClient = new client_dynamodb_1.DynamoDB({});
    let count = 0;
    let startKey = undefined;
    while (true) {
        const res = yield dbClient.scan({
            Select: "COUNT",
            TableName: event.tableName,
            ExclusiveStartKey: startKey,
            FilterExpression: event.dynamo.expression,
            ExpressionAttributeNames: event.dynamo.expressionNames,
            ExpressionAttributeValues: primitivesToString(event.dynamo.expressionValues)
        });
        count += res.Count || 0;
        // Keep looping if there is more data
        if (res.LastEvaluatedKey) {
            startKey = res.LastEvaluatedKey;
        }
        else {
            break;
        }
    }
    return count;
});
exports.handler = handler;
